#ifndef NOTES_H_
#define NOTES_H_

#include <msp430.h>

void initNotes();


#endif
