#include <msp430.h>

/* Peripherals.c and .h are where the functions that implement
 * the LEDs and keypad, etc are. It is often useful to organize
 * your code by putting like functions together in files.
 * You include the header associated with that file(s)
 * into the main file of your project. */
#include "peripherals.h"
#include <stdlib.h>
#include "notes.c"


// Declare globals here
// TODO CHANGE:
enum state {welcome, countdown, playSOM, checkError, loser, winner};
enum state state = welcome;
unsigned int MAX_COUNTER = 0;
char currKey = '0';
unsigned int timer = 0;
unsigned int note_cnt = 0;

unsigned int toggleTimer = 1;

const unsigned int TIMER_COUNTDOWN = 3;
unsigned int timer_cnt;
unsigned int time = 0;
#define ACLK 32768
#define SECINCLKTKS 200
unsigned int start_cnt = 0;
unsigned int end_cnt = 0;
unsigned int error = 0;
unsigned int toggle_start = 1;


//structs
struct Note {
    float pitch;         //in frequency (Hz)
    unsigned int duration;      //in seconds (s)
    char LED;
};

struct Note NOTE1, NOTE2, NOTE3, NOTE4, NOTE5, NOTE6, NOTE7, NOTE8, NOTE9, NOTE10, NOTE11, NOTE12, NOTE13, NOTE14, NOTE15, NOTE16, NOTE17, NOTE18, NOTE19, NOTE20, NOTE21, NOTE22, NOTE23, NOTE24, NOTE25, NOTE26, NOTE27, NOTE28, NOTE29, NOTE30, NOTE31, NOTE32;

void initNotes();
void initNotes() {

    //Note 2: C - 1
    NOTE1.pitch = 261.63;
    NOTE1.duration = 2;
    NOTE1.LED = BIT2;
    //Note 1: HIGH D
    NOTE2.pitch = 293.66;
    NOTE2.duration = 2;
    NOTE2.LED = BIT1;
    //Note 9: C - .5
    NOTE3.pitch = 261.63;
    NOTE3.duration = 1;
    NOTE3.LED = BIT2;
    //Note 3: B - .5
    NOTE4.pitch = 246.94;
    NOTE4.duration = 1;
    NOTE4.LED = BIT3;
    //Note 4: A - 2
    NOTE5.pitch = 220;
    NOTE5.duration = 2;
    NOTE5.LED = BIT4;
    //Note 5: G - .5
    NOTE6.pitch = 196;
    NOTE6.duration = .5;
    NOTE6.LED = BIT1;
    //Note 6: F - .5
    NOTE7.pitch = 174.61;
    NOTE7.duration = .5;
    NOTE7.LED = BIT2;
    //Note 7: E - 1
    NOTE8.pitch = 164.81;
    NOTE8.duration = 1;
    NOTE8.LED = BIT3;
    //Note 8: LOW D - 1
    NOTE9.pitch = 146.83;
    NOTE9.duration = 1;
    NOTE9.LED = BIT4;
    //Note 7: E - 2
    NOTE10.pitch = 164.81;
    NOTE10.duration = 2;
    NOTE10.LED = BIT3;
    //Note 7: E - 2
    NOTE11.pitch = 164.81;
    NOTE11.duration = 2;
    NOTE11.LED = BIT3;
    //Note 6: F - 1
    NOTE12.pitch = 174.61;
    NOTE12.duration = 1;
    NOTE12.LED = BIT2;
    //Note 5: G - 1
    NOTE13.pitch = 196;
    NOTE13.duration = 1;
    NOTE13.LED = BIT1;
    //Note 6: F - .5
    NOTE14.pitch = 174.61;
    NOTE14.duration = .5;
    NOTE14.LED = BIT2;
    //Note 7: E - .5
    NOTE15.pitch = 164.81;
    NOTE15.duration = .5;
    NOTE15.LED = BIT3;
    //Note 8: LOW D - 2
    NOTE16.pitch = 146.83;
    NOTE16.duration = 2;
    NOTE16.LED = BIT4;
    //Note 7: E - .5
    NOTE17.pitch = 164.81;
    NOTE17.duration = .5;
    NOTE17.LED = BIT3;
    //Note 6: F - .5
    NOTE18.pitch = 174.61;
    NOTE18.duration = .5;
    NOTE18.LED = BIT2;
    //Note 5: G - 1
    NOTE19.pitch = 196;
    NOTE19.duration = 1;
    NOTE19.LED = BIT1;
    //Note 4: A - 1
    NOTE20.pitch = 220;
    NOTE20.duration = 1;
    NOTE20.LED = BIT4;
    //Note 3: B - 4
    NOTE21.pitch = 246.94;
    NOTE21.duration = 4;
    NOTE21.LED = BIT3;
    //Note 2: C - 1
    NOTE22.pitch = 261.63;
    NOTE22.duration = 1;
    NOTE22.LED = BIT2;
    //Note 1: HIGH D
    NOTE23.pitch = 293.66;
    NOTE23.duration = 1;
    NOTE23.LED = BIT1;
    //Note 9: C - .5
    NOTE24.pitch = 261.63;
    NOTE24.duration = .5;
    NOTE24.LED = BIT2;
    //Note 3: B - .5
    NOTE25.pitch = 246.94;
    NOTE25.duration = .5;
    NOTE25.LED = BIT3;
    //Note 4: A - 2
    NOTE26.pitch = 220;
    NOTE26.duration = 2;
    NOTE26.LED = BIT4;
    //Note 5: G - .5
    NOTE27.pitch = 196;
    NOTE27.duration = .5;
    NOTE27.LED = BIT1;
    //Note 6: F - .5
    NOTE28.pitch = 174.61;
    NOTE28.duration = .5;
    NOTE28.LED = BIT2;
    //Note 7: E - 1
    NOTE29.pitch = 164.81;
    NOTE29.duration = 1;
    NOTE29.LED = BIT3;
    //Note 8: LOW D - 1
    NOTE30.pitch = 146.83;
    NOTE30.duration = 1;
    NOTE30.LED = BIT4;
    //Note 7: E - 2
    NOTE31.pitch = 164.81;
    NOTE31.duration = 2;
    NOTE31.LED = BIT3;
    //Note 7: E - 4
    NOTE32.pitch = 164.81;
    NOTE32.duration = 4;
    NOTE32.LED = BIT3;
}

// Function Prototypes
void swDelay(char numLoops);
void swDelay(char numLoops) {
    volatile unsigned int i,j;  // volatile to prevent removal in optimization
                                // by compiler. Functionally this is useless code
    for (j=0; j<numLoops; j++)
    {
        i = 50000 ;                 // SW Delay
        while (i > 0)               // could also have used while (i)
           i--;
    }
}
void configButtons();
void configButtons() {
    // Button S1: 7.0 and S4: 7.4 (these are configured correctly)
    P7SEL &= ~(BIT0 | BIT4);
    P7DIR &= ~(BIT0 | BIT4);
    P7REN |=  (BIT0 | BIT4);
    P7OUT |=  (BIT0 | BIT4);

    // Button S2: 3.6
    P3SEL &= ~(BIT6);
    P3DIR &= ~(BIT6);
    P3REN |=  (BIT6);
    P3OUT |=  (BIT6);

    //Button S3: 2.2
    P2SEL &= ~(BIT2);
    P2DIR &= ~(BIT2);
    P2REN |=  (BIT2);
    P2OUT |=  (BIT2);
}
char readButtons();
char readButtons() {
    char x;
    char y;
    char z;
    char v;

    x = (~(P7IN) & (BIT0)) << 2;  //Button S1
    y = (~(P3IN) & BIT6) >> 5;   // Button S2
    z = (~(P2IN) & BIT2) << 1;  // Button S3
    v = ~(P7IN) & (BIT4);

    char outbits = (x | y | z | v);

    return outbits;
}
void configLED(char inbits);
void configLED(char inbits) {
    P6SEL &= ~(BIT4 | BIT3 | BIT2 | BIT1);
    P6DIR |=  (BIT4 | BIT3 | BIT2 | BIT1);

    P6OUT |= inbits;
}
void startTimerA2();
void startTimerA2() {
    TA2CTL = TASSEL_1 | MC_1 | ID_0;
    TA2CCR0 = 163; //0.005 s
    TA2CCTL0 = CCIE;
}
void stopTimer();
void stopTimer() {
    TA2CTL = MC_0;
    TA2CCTL0 &= ~CCIE;
    timer_cnt = 0;
    toggleTimer = 1;
    time = 0;
}
int intToAscii(int number);
int intToAscii(int number) {
   return '0' + number;
}
int pitchToCLKTicks(int pitch);
int pitchToCLKTicks(int pitch) {
    return (ACLK / pitch) - 1;
}
void LEDOff();
void LEDOff() {
    P6SEL &= ~(BIT4 | BIT3 | BIT2 | BIT1);
    P6DIR |=  (BIT4 | BIT3 | BIT2 | BIT1);

    P6OUT &= ~(BIT4 | BIT3 | BIT2 | BIT1); // all LEDs off
}
void playNote(struct Note note);
void playNote(struct Note note) {
    startTimerA2();
    while(time < note.duration) {
        SetBuzzerPitch(pitchToCLKTicks(note.pitch));
        configLED(note.LED);

        if(P6OUT & readButtons()) {
            if(toggle_start) {
                start_cnt = timer_cnt;
                toggle_start = 0;
            }
            end_cnt = timer_cnt;
        }
    }

    int durationOffsetPos = (note.duration * SECINCLKTKS) + 100;
    int durationOffsetNeg = (note.duration * SECINCLKTKS) - 100;

    if(!(end_cnt - start_cnt >= durationOffsetNeg) || !(end_cnt - start_cnt <= durationOffsetPos)) {
        error++;
    }
    stopTimer();
    BuzzerOff();
    LEDOff();
    toggle_start = 1;

}
void displayTime(int time);
void displayTime(int timeDisplay) {
    unsigned char result[3];
             result[0] = ' ';
             result[2] = ' ';

             Graphics_clearDisplay(&g_sContext); // Clear the display

    char timeInASCII = intToAscii(timeDisplay);
    result[1] = timeInASCII;

    Graphics_drawStringCentered(&g_sContext, result , AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT); // takes in string

    Graphics_flushBuffer(&g_sContext); //refresh screen
}
void lost();
void lost() {
    Graphics_clearDisplay(&g_sContext); // Clear the display

    // Write some text to the display
    Graphics_drawStringCentered(&g_sContext, "Not In My Band", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
    Graphics_flushBuffer(&g_sContext);

    startTimerA2();

    while(time < 5) {
    }
    stopTimer();
}
void won();
void won() {
    Graphics_clearDisplay(&g_sContext); // Clear the display

    // Write some text to the display
    Graphics_drawStringCentered(&g_sContext, "Woot Woot", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
    Graphics_flushBuffer(&g_sContext);

    startTimerA2();

    while(time < 5) {
    }
    stopTimer();
}
#pragma vector=TIMER2_A0_VECTOR
    __interrupt void TimerA2_ISR() {
        timer_cnt++;

        if((timer_cnt % SECINCLKTKS) == 0) {
            time++;
        }
    }


// Main
void main(void){


    WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
                                 // You can then configure it properly, if desired

    // Some utterly useless instructions -- Step through them
    // What size does the Code Composer MSP430 Compiler use for the
    // following variable types? A float, an int, a long integer and a char

    // Useful code starts here
    initLeds();

    configDisplay();
    configKeypad();

    //enable_interrupt();
    _BIS_SR(GIE);

    initNotes();
    struct Note arr_note[32] = {NOTE1, NOTE2, NOTE3, NOTE4, NOTE5, NOTE6, NOTE7, NOTE8, NOTE9, NOTE10, NOTE11, NOTE12, NOTE13, NOTE14, NOTE15, NOTE16, NOTE17, NOTE18, NOTE19, NOTE20, NOTE21, NOTE22, NOTE23, NOTE24, NOTE25, NOTE26, NOTE27, NOTE28, NOTE29, NOTE30, NOTE31, NOTE32};



    // We are now done writing to the display.  However, if we stopped here, we would not
    // see any changes on the actual LCD.  This is because we need to send our changes
    // to the LCD, which then refreshes the display.
    // Since this is a slow operation, it is best to refresh (or "flush") only after
    // we are done drawing everything we need.
    Graphics_flushBuffer(&g_sContext);


    setLeds(0);
    configButtons();

    while (1) {   // Forever loop
        currKey = getKey();

        switch(state) {

        case welcome:
            Graphics_drawStringCentered(&g_sContext, "Welcome To:", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
            Graphics_drawStringCentered(&g_sContext, "MSP430 Hero", AUTO_STRING_LENGTH, 48, 45, TRANSPARENT_TEXT);
            Graphics_drawStringCentered(&g_sContext, "Press * to Start", AUTO_STRING_LENGTH, 48, 55, TRANSPARENT_TEXT);

            Graphics_flushBuffer(&g_sContext);

            if(currKey == '*') {
                Graphics_clearDisplay(&g_sContext); // Clear the display
                state = countdown;
            }
            break;


        case countdown:
            Graphics_drawStringCentered(&g_sContext, "MSP430 Hero", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);

            setLeds(1);
            Graphics_drawStringCentered(&g_sContext, "3", AUTO_STRING_LENGTH, 48, 55, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            swDelay(4);

            setLeds(3);
            Graphics_drawStringCentered(&g_sContext, "2", AUTO_STRING_LENGTH, 48, 65, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            swDelay(4);

            setLeds(7);
            Graphics_drawStringCentered(&g_sContext, "1", AUTO_STRING_LENGTH, 48, 75, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            swDelay(4);

            setLeds(15);
            Graphics_drawStringCentered(&g_sContext, "go", AUTO_STRING_LENGTH, 48, 85, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            swDelay(4);
            setLeds(0);

            Graphics_clearDisplay(&g_sContext); // Clear the display
            state = playSOM;
            break;

        case playSOM:
            playNote(arr_note[(note_cnt % 32)]);
            note_cnt++;
            state = checkError;
            break;

        case checkError:
            if(error >= 4) {
                Graphics_clearDisplay(&g_sContext);
                state = loser;
            } else if(note_cnt >= 8) {
                Graphics_clearDisplay(&g_sContext);
                state = winner;
            }
            else {
                state = playSOM;
            }
            break;

        case loser:
            lost();
            state = welcome;
            error = 0;
            note_cnt = 0;
            Graphics_clearDisplay(&g_sContext);
            break;

        case winner:
            won();
            state = welcome;
            error = 0;
            note_cnt = 0;
            Graphics_clearDisplay(&g_sContext);
            break;
        }
    }
}  // end while (1)
